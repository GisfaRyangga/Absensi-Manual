package com.example.presensi;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SecondFragment extends Fragment {
    EditText emailregis, passwordregis, namaregis;
    Button btnregis;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_second, container, false);

        emailregis = view.findViewById(R.id.regis_email);
        passwordregis = view.findViewById(R.id.regis_pass);
        namaregis = view.findViewById(R.id.regis_nama);

        btnregis = view.findViewById(R.id.register);
        btnregis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(namaregis.getText().toString())) {
                    Toast.makeText(getActivity(), "Kolom Nama Lengkap tidak boleh kosong !",
                            Toast.LENGTH_SHORT).show();
                }
                else if  (TextUtils.isEmpty(emailregis.getText().toString())) {
                    Toast.makeText(getActivity(), "Kolom Email tidak boleh kosong !",
                            Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(passwordregis.getText().toString())) {
                    Toast.makeText(getActivity(), "Kolom Password tidak boleh kosong !",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(getActivity(),"Daftar Berhasil!",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getActivity(), MainActivity.class);
                    startActivity(intent);
                }
            }
        });
        return view;
    }
}