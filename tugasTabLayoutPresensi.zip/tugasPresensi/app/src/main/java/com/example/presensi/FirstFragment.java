package com.example.presensi;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FirstFragment extends Fragment {
    EditText emaillogin, passlogin;
    Button btnlogin;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_first, container, false);

        emaillogin = view.findViewById(R.id.login_email);
        passlogin = view.findViewById(R.id.login_pass);

        btnlogin = view.findViewById(R.id.login);
        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (TextUtils.isEmpty(emaillogin.getText().toString())) {
                    Toast.makeText(getActivity(), "Kolom Email tidak boleh kosong !",
                            Toast.LENGTH_SHORT).show();
                }
                else if (TextUtils.isEmpty(passlogin.getText().toString())) {
                    Toast.makeText(getActivity(), "Kolom Password tidak boleh kosong !",
                            Toast.LENGTH_SHORT).show();
                }
                else {
                    Toast.makeText(getActivity(),"Login Berhasil!",Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getActivity(), MainActivity.class);
                    startActivity(intent);
                }
            }
        });
        return view;
    }
}