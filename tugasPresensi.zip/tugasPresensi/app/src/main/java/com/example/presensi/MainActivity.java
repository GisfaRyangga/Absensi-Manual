package com.example.presensi;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    String mSpinnerText;
    Button alertButton;
    LinearLayout alasan;
    Spinner spinnerSp;
    EditText tanggal;
    EditText waktu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        alasan = findViewById(R.id.ll_keterangan);
        spinnerSp = findViewById(R.id.label_spinner);
        tanggal = findViewById(R.id.et_datepicker);
        waktu = findViewById(R.id.et_timepicker);

        tanggal.setKeyListener(null);
        waktu.setKeyListener(null);

        Spinner spinner = findViewById(R.id.label_spinner);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.labels_array, android.R.layout.simple_spinner_item);


        spinnerSp.setAdapter(adapter);
        if (spinnerSp != null){
            spinnerSp.setOnItemSelectedListener(this);
        }

        tanggal.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if(b){showDatePicker();}
            }
        });

        tanggal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDatePicker();
            }
        });

        waktu.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if(b){showTimePicker();}
            }
        });

        waktu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showTimePicker();
            }
        });

        alertButton = findViewById(R.id.btn_submit);
        alertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAlertDialog();
            }
        });

        findViewById(R.id.et_datepicker).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePicker();
            }
        });

        findViewById(R.id.et_timepicker).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showTimePicker();
            }
        });
    }

    public void showDatePicker(){
        DialogFragment dateFragment = new com.example.presensi.DatePickerFragment();
        dateFragment.show(getSupportFragmentManager(), "date-picker");
    }

    public void showTimePicker(){
        DialogFragment timeFragment = new com.example.presensi.TimePickerFragment();
        timeFragment.show(getSupportFragmentManager(), "time-picker");
    }

    public void showAlertDialog() {
        AlertDialog.Builder alertBuilder = new AlertDialog.Builder(MainActivity.this);
        alertBuilder.setTitle("Konfirmasi");
        alertBuilder.setMessage("Apakah kamu sudah yakin data yang akan kamu kirim sudah sesuai?");

        alertBuilder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(getApplicationContext(), "Absen berhasil", Toast.LENGTH_SHORT).show();
                finish();
                startActivity(getIntent());
            }
        });

        alertBuilder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which){}
        });
        alertBuilder.show();
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        mSpinnerText = adapterView.getItemAtPosition(position).toString();
        if (mSpinnerText.equals("Hadir tepat waktu")){
            alasan.setVisibility(View.INVISIBLE);
        }
        else alasan.setVisibility(View.VISIBLE);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        alasan.setVisibility(View.INVISIBLE);
    }

    public void processDatePickerResult(int year, int month, int day){
        String day_string = Integer.toString(day);
        String month_string = Integer.toString(month+1);
        String year_string = Integer.toString(year);

        String dateMessage = day_string + "-" + month_string + "-" + year_string;
        tanggal.setText(dateMessage);
    }

    public void processTimePickerResult(int hour, int minutes){
        String hour_string = Integer.toString(hour);
        String minutes_string = Integer.toString(minutes);

        String timeMessage = hour_string + ":" + minutes_string;
        waktu.setText(timeMessage);
    }
}